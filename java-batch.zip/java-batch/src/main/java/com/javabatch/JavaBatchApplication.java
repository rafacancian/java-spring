package com.javabatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaBatchApplication.class, args);
	}

}
